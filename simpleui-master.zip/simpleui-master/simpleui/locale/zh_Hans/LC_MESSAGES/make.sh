#!/bin/zsh
msgfmt django.po -o django.mo
