# Contributing

Fork the original repository at: https://github.com/shahraizali/awesome-django
Send a merge request with your awesome Django apps, projects or resources.
By contributing you agree to abide by the Code of Merit.
