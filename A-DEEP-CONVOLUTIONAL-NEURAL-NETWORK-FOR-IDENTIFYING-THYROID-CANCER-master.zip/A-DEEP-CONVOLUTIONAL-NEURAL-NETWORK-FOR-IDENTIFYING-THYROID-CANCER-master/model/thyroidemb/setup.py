from setuptools import setup, find_packages

setup(
    name='thyroidemb',
    version='0.1.0',
    url='',
    author='U-Hack Med 2019 Team 2',
    author_email='',
    description='Embedding of thyroid images',
    packages=find_packages(),    
    install_requires=[],
)