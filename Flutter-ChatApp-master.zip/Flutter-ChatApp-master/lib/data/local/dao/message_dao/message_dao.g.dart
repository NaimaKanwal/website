// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'message_dao.dart';

// **************************************************************************
// DaoGenerator
// **************************************************************************

mixin _$MessageDaoMixin on DatabaseAccessor<AppDatabase> {
  $MessagesTableTable get messagesTable => attachedDatabase.messagesTable;
}
