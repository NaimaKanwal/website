// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'recent_chat_dao.dart';

// **************************************************************************
// DaoGenerator
// **************************************************************************

mixin _$RecentChatDaoMixin on DatabaseAccessor<AppDatabase> {
  $RecentChatTableTable get recentChatTable => attachedDatabase.recentChatTable;
}
