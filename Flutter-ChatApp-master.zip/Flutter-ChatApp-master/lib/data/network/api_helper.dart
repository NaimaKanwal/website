
import 'package:socketchat/data/network/api_service/message_service/message_api_helper.dart';
import 'package:socketchat/data/network/api_service/users/user_api_helper.dart';

abstract class ApiHelper implements UserApiHelper,MessageApiHelper{

}