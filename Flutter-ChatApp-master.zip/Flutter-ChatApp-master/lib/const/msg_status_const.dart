class MsgStatus{

  static const int failed = -1;
  static const int pending = 1;
  static const int sent = 2;
  static const int delivered = 3;
  static const int seen = 4;

}