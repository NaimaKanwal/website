class AppConst{

  static const String placeHolderImageUri = "https";
  static const String placeHolderSenderName = "Het";
  static const String defaultStatusOfUser = "Hey, I'm using socketChat";


  static const String profilePictureStoragePath = "/profile_images/";
  static const String compressedProfilePictureStoragePath = "/compressed_profile_images/";
  static const String chatSharedImageStoragePath = "/chat_shared_image/";

}
