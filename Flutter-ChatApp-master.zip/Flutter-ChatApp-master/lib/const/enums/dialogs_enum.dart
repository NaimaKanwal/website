enum dialogEnum { saveOrNot, success, confirmation, failure,permission }
