enum msgTypeEnum {txt,image}
