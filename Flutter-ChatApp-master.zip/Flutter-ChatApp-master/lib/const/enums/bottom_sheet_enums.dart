enum bottomSheetEnum { basic, error, noInternet,editProfile }
