class SharedPrefConst{
  static const String notificationStatus = "notificationStatus";
  static const String userOfflineDataModel = "userOfflineDataModel";

}