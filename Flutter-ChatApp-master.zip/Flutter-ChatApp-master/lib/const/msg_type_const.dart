class MsgType{

  static const String txt = "txt";
  static const String image = "image";

}