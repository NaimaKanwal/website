package com.chatapp.socketchat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
